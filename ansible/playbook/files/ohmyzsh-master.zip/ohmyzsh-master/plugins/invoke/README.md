# Invoke plugin

This plugin adds completion for [invoke](https://github.com/pyinvoke/invoke).

To use it, add `invoke` to the plugins array in your `~/.zshrc` file:

```zsh
plugins=(... invoke)
```

